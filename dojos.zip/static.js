define(['./types'], function(types){
	return function(path){
		
		return {
			status: 200
			,content: null
			,length: 0
		};
	}
});