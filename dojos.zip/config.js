define({
	sites: [{
		name: 'weibo'
		,location: '../weibo'
		,title: 'Weibo'
		,port: 1338
	},{
		name: 'workspace'
		,location: '../'
		,title: 'Workspace'
		,port: 1339
	}]
});