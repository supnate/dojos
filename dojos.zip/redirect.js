define({
	route: function(url){
		return url;
	}
});
