Dojos is a light-weight Web Server implemented by Dojo on NodeJS.
